<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'Bachir Jumaa Polyclinic'=>'Bachir Jumaa Polyclinic',
    'first slide f' => 'WE ARE TAKE CKARE',
    'first slide s' => 'OF YOUR KIDS',
    'Book Now'=>'Book Now',
    'second slide'=>'Enhance your beauty',
    'third slide'=>'Feel Safe with us',
    'Clinics'=>'Clinics',
    'Read More'=>'Read More',
    'Portfolio'=>'Portfolio',
    'All'=>'All',
    'Our Doctors'=>'Our Doctors',
    'Viedos'=>'Viedos',
    'Make an Appointment'=>'Make an Appointment',
    'Name'=>'Your Name ',
    'Your Phone'=>'Your Phone',
    'Your Email'=>'Your Email',
    'Choice Departmint'=>'Choice Departmint',
    'Choice DateTime'=>'Choice DateTime',
    'Address'=>'Address',
    'Email'=>'Email',
    'Enter your  email'=>'Enter your  email',
    'Enter your  phone'=>'Enter your  phone',
    'Enter your name'=>'Enter your name',
    'Contact Us'=>'Contact Us',
    'Phone'=>'Phone',
    'DR'=>'DR',
    'Our Doctors'=>'Our Doctors',
    'Special Interest'=>'Special Interest',
    'CERTIFICATE AND AWARDS'=>'CERTIFICATE AND AWARDS',
    'About Us'=>'About Us',
    'OUR MISSION'=>'OUR MISSION',
    'OUR VISION'=>'OUR VISION',
    'FACILITIES'=>'FACILITIES',
    'Clinic'=>'Clinic',
    'Our Services'=>'Our Services',
    'More'=>'More',
    'Contact Information'=>'Contact Information',
    'Message'=>'Message',
    'Insurance'=>'Insurance',
    'Our Portfolio'=>'Our Portfolio',
    'Enter your message'=>'Enter your message',
    'Home'=>'Home',
    'About'=>'About',
    'Clinics'=>'Clinics',
    'Portfolio'=>'Portfolio',
    'Our Doctors'=>'Our Doctors',
    'Insurance'=>'Insurance',
    'Contact'=>'Contact Us',
    'YourName'=>'Your Name',
    'language'=>'ع',
    '404'=>'Page Not Found',
    'Sorry'=>'Sorry The Page Nout Found return to home page',
    'testimonial'=>'Testimonial',






];
